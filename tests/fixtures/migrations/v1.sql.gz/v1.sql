PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS watchlist (
  id TEXT PRIMARY KEY,
  category TEXT NOT NULL,
  search_urls TEXT NOT NULL,
  models TEXT NOT NULL,
  max_price INTEGER NOT NULL,
  seller TEXT,
  poll_minutes INTEGER NOT NULL DEFAULT 20,
  enabled INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE IF NOT EXISTS listings (
  avito_id TEXT PRIMARY KEY,
  url TEXT NOT NULL,
  first_seen TEXT NOT NULL,
  last_seen TEXT NOT NULL,
  status TEXT NOT NULL,
  title TEXT,
  price INTEGER,
  description TEXT,
  params TEXT,
  city TEXT,
  delivery INTEGER,
  seller_id TEXT,
  seller_type TEXT,
  watchlist_id TEXT,
  raw_path TEXT,
  fingerprint TEXT,
  price_suspect INTEGER DEFAULT 0
);

CREATE TABLE IF NOT EXISTS listing_events (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  avito_id TEXT NOT NULL,
  ts TEXT NOT NULL,
  kind TEXT NOT NULL,
  payload TEXT,
  FOREIGN KEY (avito_id) REFERENCES listings(avito_id)
);

CREATE TABLE IF NOT EXISTS price_history (
  listing_id TEXT NOT NULL,
  ts TEXT NOT NULL,
  price INTEGER NOT NULL,
  PRIMARY KEY (listing_id, ts)
);

CREATE TABLE IF NOT EXISTS images (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  avito_id TEXT NOT NULL,
  url TEXT NOT NULL,
  local_path TEXT,
  phash TEXT
);

CREATE TABLE IF NOT EXISTS sellers (
  seller_id TEXT PRIMARY KEY,
  kind TEXT,
  rating REAL,
  reviews INTEGER,
  registered TEXT,
  listings_count INTEGER,
  fetched_at TEXT
);

CREATE TABLE IF NOT EXISTS extractions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  avito_id TEXT NOT NULL,
  extractor_version TEXT NOT NULL,
  model_id TEXT,
  specs TEXT,
  condition TEXT,
  defects TEXT,
  confidence REAL,
  source TEXT,
  mismatch INTEGER,
  low_info INTEGER,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS evaluations (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  avito_id TEXT NOT NULL,
  fair_price INTEGER,
  fair_low INTEGER,
  fair_high INTEGER,
  discount REAL,
  ev INTEGER,
  risk REAL,
  verdict TEXT,
  reasons TEXT,
  skip_reason TEXT,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS market_snapshots (
  model_id TEXT NOT NULL,
  condition TEXT NOT NULL,
  kind TEXT NOT NULL DEFAULT 'ask',
  ts TEXT NOT NULL,
  n INTEGER,
  median INTEGER,
  q10 INTEGER,
  q25 INTEGER,
  q75 INTEGER,
  q90 INTEGER,
  PRIMARY KEY (model_id, condition, kind, ts)
);

CREATE TABLE IF NOT EXISTS notifications (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  avito_id TEXT NOT NULL,
  channel TEXT NOT NULL,
  idempotency_key TEXT UNIQUE,
  verdict TEXT,
  sent_at TEXT,
  feedback TEXT,
  status TEXT DEFAULT 'sent',
  attempts INTEGER DEFAULT 1,
  next_try_at TEXT,
  payload TEXT,
  created_at TEXT
);

CREATE TABLE IF NOT EXISTS metrics (
  day TEXT PRIMARY KEY,
  requests INTEGER DEFAULT 0,
  http_429 INTEGER DEFAULT 0,
  http_403 INTEGER DEFAULT 0,
  parse_ok INTEGER DEFAULT 0,
  parse_fail INTEGER DEFAULT 0,
  hits_total INTEGER DEFAULT 0,
  hits_no_price INTEGER DEFAULT 0,
  anchor_fallback INTEGER DEFAULT 0,
  empty_ok INTEGER DEFAULT 0,
  unknown_empty INTEGER DEFAULT 0,
  carousel_discarded INTEGER DEFAULT 0
);

CREATE TABLE IF NOT EXISTS runtime (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS products (
  model_id TEXT PRIMARY KEY,
  category TEXT NOT NULL,
  brand TEXT,
  aliases TEXT,
  msrp_new INTEGER,
  fake_risk TEXT
);

CREATE TABLE IF NOT EXISTS product_profiles (
  model_id TEXT PRIMARY KEY,
  category TEXT NOT NULL,
  canonical_name TEXT NOT NULL,
  brand TEXT,
  profile_json TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE VIRTUAL TABLE IF NOT EXISTS listings_fts USING fts5(
  avito_id UNINDEXED,
  title,
  description,
  params,
  tokenize = 'unicode61'
);

CREATE TRIGGER IF NOT EXISTS listings_ai AFTER INSERT ON listings BEGIN
  INSERT INTO listings_fts(avito_id, title, description, params)
  VALUES (new.avito_id, COALESCE(new.title, ''), COALESCE(new.description, ''), COALESCE(new.params, ''));
END;

CREATE TRIGGER IF NOT EXISTS listings_ad AFTER DELETE ON listings BEGIN
  DELETE FROM listings_fts WHERE avito_id = old.avito_id;
END;

CREATE TRIGGER IF NOT EXISTS listings_au AFTER UPDATE ON listings BEGIN
  DELETE FROM listings_fts WHERE avito_id = old.avito_id;
  INSERT INTO listings_fts(avito_id, title, description, params)
  VALUES (new.avito_id, COALESCE(new.title, ''), COALESCE(new.description, ''), COALESCE(new.params, ''));
END;

